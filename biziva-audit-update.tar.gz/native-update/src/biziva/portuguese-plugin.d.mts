import type {Plugin} from 'vite';
export default function portugueseUI(): Plugin;
export declare function labelRanges(code:string,id:string): Array<{start:number,end:number,text:string,kind:string}>;
export declare function translateLabels(code:string,id:string,labels:Record<string,string>):string;

// Build-time UI translation. User documents and internal object keys are untouched.
import ts from 'typescript';
import {parse} from '@vue/compiler-sfc';
import {baseParse} from '@vue/compiler-dom';
import {readFileSync} from 'node:fs';
const chinese=/[\u3400-\u9fff]/;
export function labelRanges(code, id) {
  const ranges=[];
  const script=(text,offset,context='script')=>{
    const source=ts.createSourceFile(id,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
    const visit=node=>{
      if(ts.isTemplateExpression(node)){
        const parts=[node.head,...node.templateSpans.map(span=>span.literal)];
        for(const part of parts)if(chinese.test(part.text))ranges.push({start:offset+part.getStart(source)+1,end:offset+part.getEnd()-(part.kind===ts.SyntaxKind.TemplateTail?1:2),text:part.text,kind:context==='binding-script'?'binding-template':'template'});
      }
      if(ts.isStringLiteralLike(node)&&chinese.test(node.text)&&node.parent?.name!==node&&!(ts.isElementAccessExpression(node.parent)&&node.parent.argumentExpression===node)){
        ranges.push({start:offset+node.getStart(source),end:offset+node.getEnd(),text:node.text,kind:context});
      }
      ts.forEachChild(node,visit);
    };visit(source);
  };
  if(id.endsWith('.vue')){
    const {descriptor,errors}=parse(code,{filename:id});if(errors.length)throw Error('Invalid Vue source: '+id);
    for(const block of [descriptor.script,descriptor.scriptSetup])if(block)script(block.content,block.loc.start.offset);
    if(descriptor.template){
      const block=descriptor.template;const offset=block.loc.start.offset;
      const visit=node=>{
        if(node.type===2&&chinese.test(node.content))ranges.push({start:offset+node.loc.start.offset,end:offset+node.loc.end.offset,text:node.content,kind:'text'});
        if(node.type===5)script(node.content.content,offset+node.content.loc.start.offset);
        for(const prop of node.props||[]){
          if(prop.type===6&&prop.value&&chinese.test(prop.value.content))ranges.push({start:offset+prop.value.loc.start.offset,end:offset+prop.value.loc.end.offset,text:prop.value.content,kind:'attribute'});
          if(prop.type===7&&prop.exp)script(prop.exp.content,offset+prop.exp.loc.start.offset,'binding-script');
        }
        for(const child of node.children||[])visit(child);
      };visit(baseParse(block.content,{isVoidTag:tag=>['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'].includes(tag)}));
    }
  }else script(code,0);
  return ranges;
}
const html=text=>text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/\{/g,'&#123;').replace(/\}/g,'&#125;');
export function translateLabels(code,id,labels){
  const edits=labelRanges(code,id).filter(r=>typeof labels[r.text]==='string');
  for(const r of edits.sort((a,b)=>b.start-a.start)){
    const kind=r.kind.replace(/^binding-/,'');
    let value=kind==='script'?JSON.stringify(labels[r.text]).replace(/</g,'\\u003c'):kind==='template'?JSON.stringify(labels[r.text]).slice(1,-1).replace(/`/g,'\\`').replace(/\$\{/g,'\\${').replace(/</g,'\\u003c'):kind==='attribute'?'"'+html(labels[r.text])+'"':html(labels[r.text]);
    if(r.kind.startsWith('binding-'))value=html(value);
    code=code.slice(0,r.start)+value+code.slice(r.end);
  }
  return code;
}
export default function portugueseUI(){
  const labels=JSON.parse(readFileSync(new URL('./pt-labels.json',import.meta.url),'utf8'));
  let sourceRoot;
  return {name:'biziva-portuguese-ui',enforce:'pre',configResolved(config){sourceRoot=config.root.replace(/\\/g,'/')+'/src/';},transform(code,id){
    const file=id.replace(/\\/g,'/');
    if(!file.startsWith(sourceRoot)||file.includes('?')||file.includes('/biziva/')||file.endsWith('/configs/font.ts')||!/\.(vue|ts)$/.test(file))return null;
    return {code:translateLabels(code,file,labels),map:null};
  }};
}
